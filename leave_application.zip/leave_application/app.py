from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, DateField, SelectField
from wtforms.validators import DataRequired, ValidationError
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime


# ───────────────────────────────────────────────

# FLASK APP + DATABASE
# ───────────────────────────────────────────────
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///leave_system.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"


# ───────────────────────────────────────────────
# MODELS
# ───────────────────────────────────────────────
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # employee / manager / hr

    def set_password(self, pwd):
        self.password_hash = generate_password_hash(pwd)

    def check_password(self, pwd):
        return check_password_hash(self.password_hash, pwd)


class Leave(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.String(255))
    status = db.Column(db.String(50), default="Pending (Manager)")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    employee = db.relationship('User')


# ───────────────────────────────────────────────
# LOGIN MANAGER
# ───────────────────────────────────────────────
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ───────────────────────────────────────────────
# FORMS
# ───────────────────────────────────────────────
class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class LeaveForm(FlaskForm):
    start_date = DateField("Start Date", validators=[DataRequired()], format='%Y-%m-%d')
    end_date = DateField("End Date", validators=[DataRequired()], format='%Y-%m-%d')
    reason = TextAreaField("Reason", validators=[DataRequired()])
    submit = SubmitField("Submit Leave")

    def validate_end_date(self, field):
        if self.start_date.data and field.data < self.start_date.data:
            raise ValidationError("End date must be after start date.")


class DecisionForm(FlaskForm):
    decision = SelectField("Decision", choices=[("approve","Approve"),("reject","Reject")])
    submit = SubmitField("Submit Decision")


# ───────────────────────────────────────────────
# ROUTES
# ───────────────────────────────────────────────

@app.route("/")
def home():
    return render_template("index.html")


# ---------------------- Register ----------------------
@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        role = request.form["role"]

        if User.query.filter_by(username=username).first():
            flash("Username already taken", "danger")
            return redirect(url_for("register"))

        u = User(username=username, role=role)
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        flash("User registered", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


# ---------------------- Login ----------------------
@app.route("/login", methods=["GET","POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        u = User.query.filter_by(username=form.username.data).first()
        if u and u.check_password(form.password.data):
            login_user(u)
            return redirect(url_for("dashboard"))
        flash("Invalid credentials", "danger")
    return render_template("login.html", form=form)


# ---------------------- Logout ----------------------
@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


# ---------------------- Dashboard ----------------------
@app.route('/dashboard')
@login_required
def dashboard():

    # HR should NOT see a dashboard → redirect to HR history
    if current_user.role == "hr":
        return redirect(url_for("hr_history"))

    # Manager → only NEW pending leave requests
    if current_user.role == "manager":
        leave_requests = Leave.query.filter_by(status="Pending (Manager)").all()
        return render_template('dashboard.html', leaves=leave_requests)

    # Employee → only their own leaves
    if current_user.role == "employee":
        leave_requests = Leave.query.filter_by(employee_id=current_user.id).all()
        return render_template('dashboard.html', leaves=leave_requests)

    return redirect(url_for("home"))


# ---------------------- Apply Leave ----------------------
@app.route("/leave/apply", methods=["GET","POST"])
@login_required
def apply_leave():
    form = LeaveForm()
    if form.validate_on_submit():
        leave = Leave(
            employee_id=current_user.id,
            start_date=form.start_date.data,
            end_date=form.end_date.data,
            reason=form.reason.data,
            status="Pending (Manager)"
        )
        db.session.add(leave)
        db.session.commit()
        flash("Leave submitted", "success")
        return redirect(url_for("dashboard"))
    return render_template("leave_form.html", form=form)


# ---------------------- Leave View ----------------------
@app.route("/leave/<int:leave_id>")
@login_required
def leave_view(leave_id):
    leave = Leave.query.get_or_404(leave_id)
    return render_template("leave_view.html", leave=leave)


# ---------------------- Manager Decision ----------------------
@app.route("/manager/decision/<int:leave_id>", methods=["GET","POST"])
@login_required
def manager_decision(leave_id):
    if current_user.role != "manager":
        flash("Unauthorized", "danger")
        return redirect(url_for("dashboard"))

    leave = Leave.query.get_or_404(leave_id)
    form = DecisionForm()

    if form.validate_on_submit():
        leave.status = "Approved" if form.decision.data == "approve" else "Rejected"
        db.session.commit()
        flash("Decision submitted", "success")
        return redirect(url_for("dashboard"))

    return render_template("manager_decision.html", leave=leave, form=form)


# ---------------------- Manager Leave History ----------------------
@app.route("/manager/history")
@login_required
def manager_history():
    if current_user.role != "manager":
        flash("Unauthorized", "danger")
        return redirect(url_for("dashboard"))

    leaves = Leave.query.order_by(Leave.created_at.desc()).all()
    return render_template("history.html", leaves=leaves)


# ---------------------- HR Leave History ----------------------
@app.route("/hr/history")
@login_required
def hr_history():
    if current_user.role != "hr":
        flash("Unauthorized", "danger")
        return redirect(url_for("dashboard"))

    leaves = Leave.query.order_by(Leave.created_at.desc()).all()
    return render_template("history.html", leaves=leaves)


# ───────────────────────────────────────────────
# RUN SERVER
# ───────────────────────────────────────────────
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
