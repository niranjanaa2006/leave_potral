from flask import Blueprint, render_template, redirect, url_for, flash, abort, request
from flask_login import login_required, current_user
from app import db
from app import Leave
from forms import LeaveForm

employee_bp = Blueprint('employee', __name__)


def role_required(role):
    def decorator(f):
        from functools import wraps
        @wraps(f)
        def wrapper(*a, **k):
            if current_user.role != role:
                flash("Access denied: insufficient permissions.", "danger")
                return redirect(url_for("dashboard.dashboard"))
            return f(*a, **k)
        return wrapper
    return decorator


@employee_bp.route('/leave/new', methods=['GET','POST'])
@login_required
@role_required('employee')
def leave_new():
    form = LeaveForm()
    if form.validate_on_submit():
        leave = Leave(
            employee_id=current_user.id,
            start_date=form.start_date.data,
            end_date=form.end_date.data,
            reason=form.reason.data,
            status='Pending (Manager)'
        )
        db.session.add(leave)
        db.session.commit()
        flash('Leave submitted and pending manager approval', 'success')
        return redirect(url_for('dashboard.dashboard'))
    return render_template('leave_form.html', form=form)


@employee_bp.route('/leave/<int:leave_id>')
@login_required
def leave_view(leave_id):
    leave = Leave.query.get_or_404(leave_id)
    if current_user.role == 'employee' and leave.employee_id != current_user.id:
        abort(403)
    return render_template('leave_view.html', leave=leave)


@employee_bp.route('/leave/<int:leave_id>/delete', methods=['POST'])
@login_required
@role_required('employee')
def leave_delete(leave_id):
    leave = Leave.query.get_or_404(leave_id)
    if leave.employee_id != current_user.id:
        abort(403)
    if leave.status != 'Pending (Manager)':
        flash('Only leaves with status Pending (Manager) can be cancelled by employee', 'danger')
        return redirect(url_for('dashboard.dashboard'))
    db.session.delete(leave)
    db.session.commit()
    flash('Leave cancelled', 'success')
    return redirect(url_for('dashboard.dashboard'))
