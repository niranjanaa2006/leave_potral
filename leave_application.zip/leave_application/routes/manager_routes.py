from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db, Leave
from forms import DecisionForm

manager_bp = Blueprint('manager', __name__)

# Role check decorator
def role_required(role):
    def decorator(f):
        from functools import wraps
        @wraps(f)
        def wrapper(*args, **kwargs):
            if current_user.role != role:
                flash("Access denied: insufficient permissions.", "danger")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------- Manager Decision Page ----------------------
@manager_bp.route('/manager/decision/<int:leave_id>', methods=['GET', 'POST'])
@login_required
@role_required('manager')
def manager_decision(leave_id):
    leave = Leave.query.get_or_404(leave_id)

    # Manager can only act on pending leave
    if leave.status != "Pending (Manager)":
        flash("Leave is not pending manager decision.", "danger")
        return redirect(url_for("dashboard"))

    form = DecisionForm()

    if form.validate_on_submit():
        if form.decision.data == "approve":
            leave.status = "Approved"    # or "Pending (HR)" if HR needs next step
            flash("Leave approved by Manager.", "success")
        else:
            leave.status = "Rejected"
            flash("Leave rejected by Manager.", "info")

        db.session.commit()
        return redirect(url_for("dashboard"))

    return render_template("manager_decision.html", leave=leave, form=form)


# ---------------------- Manager Leave History ----------------------
@manager_bp.route('/manager/history')
@login_required
@role_required('manager')
def manager_history():
    leaves = Leave.query.order_by(Leave.created_at.desc()).all()
    return render_template("history.html", leaves=leaves)
