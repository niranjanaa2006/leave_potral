from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app import Leave

hr_bp = Blueprint('hr', __name__)

# Role-based access decorator
def role_required(role):
    def decorator(f):
        from functools import wraps
        @wraps(f)
        def wrapper(*args, **kwargs):
            if current_user.role != role:
                flash("Access denied: insufficient permissions.", "danger")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return decorator


@hr_bp.route('/hr/history')
@login_required
@role_required('hr')
def hr_history():
    leaves = Leave.query.order_by(Leave.created_at.desc()).all()
    return render_template('history.html', leaves=leaves, title=" Leave History")
