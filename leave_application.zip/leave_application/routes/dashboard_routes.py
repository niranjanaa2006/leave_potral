from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from app import db, Leave

dashboard_bp = Blueprint('dashboard_bp', __name__)

# -------------------- Home Page --------------------
@dashboard_bp.route('/')
def index():
    return render_template('index.html')


# -------------------- Dashboard --------------------
@dashboard_bp.route("/dashboard")
@login_required
def dashboard():

    # HR should NOT have dashboard → redirect to HR history
    if current_user.role == "hr":
        return redirect(url_for("hr.hr_history"))

    # Manager dashboard → only NEW pending requests
    if current_user.role == "manager":
        leaves = Leave.query.filter_by(status="Pending (Manager)").all()
        return render_template("dashboard.html", leaves=leaves)

    # Employee dashboard → only their own leaves
    if current_user.role == "employee":
        leaves = Leave.query.filter_by(employee_id=current_user.id).all()
        return render_template("dashboard.html", leaves=leaves)

    # Fallback
    return redirect(url_for("home"))


# -------------------- Manager Leave History --------------------
@dashboard_bp.route("/manager/history")
@login_required
def manager_history():
    if current_user.role != "manager":
        return redirect(url_for("dashboard"))

    leaves = Leave.query.order_by(Leave.created_at.desc()).all()
    return render_template("history.html", leaves=leaves)
